def funFile():
    print('this is a fun in file')

print('this is file.py')