def music():
    print('this is a fun in musicEnjoy')

print('this is musicEnjoy.py')

# 有点甜