import os

if __name__ == '__main__':
    path = 'C:\\Users\\LuShengcan\\Desktop\\123'
    for file in os.listdir(path):
        print(file)

