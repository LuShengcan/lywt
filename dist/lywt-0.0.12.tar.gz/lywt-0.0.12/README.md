# lywt

## 包介绍

>​		lywt 是一个个人自用的小工具合集（当然也可以供广大网友共同使用）。该合集目前包括了音乐爬虫、大文件分割、文件内容 MD5 校验等功能。同时，该合集也在持续更新中，欢迎网友们提出新的需求，本人会酌情进行添加。



## 跳转

[musicEnjoy](#musicEnjoy)

[fileCut](#fileCut)

[fileMD5_gui](#fileMD5_gui)



# 如何下载

- 你可以在 dist 目录里下载到最新的和老版本的 lywt
- 同时你可以使用命令行 pip install lywt 在你当前的 python 环境中安装 lywt 的所有工具或选择性安装部分工具



# musicEnjoy



# fileCut



# fileMD5_gui



