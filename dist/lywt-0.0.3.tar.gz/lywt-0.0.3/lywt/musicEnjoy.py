print('this is musicEnjoy.py')

# 有点甜